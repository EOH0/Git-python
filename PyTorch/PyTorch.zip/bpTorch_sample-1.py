import torch
import torch.nn as nn
import time

def train():
   start_time = time.time()

   f_in = open("C:\\Users\\seonh\\Documents\\Backup\\Univ\\ProgrammingC\\Python\\PyTorch\\inputs.txt", "r") # 학습 데이터가 저장된 파일 128*128 개의 입력값(0~255)과 학습해야할 결과값(0~4)
   lines = f_in.readlines()
   f_in.close()
   
   # 학습 데이터파일에서 데이터를 읽음
   for i in range(len(lines)):
      lines[i] = lines[i].split()
      lines[i] = list(map(int, lines[i]))

   inputs = []
   outputs = []
   # 학습 데이터를 읽어 입력데이터는 inputs에 결과값은 outputs에 저장
   for lineVal in lines:
      
      line = lineVal[:-1]
      inputs.append(line)
      #print("input = ", line) # 입력값
      line = [0.1 for i in range(5)]
      line[lineVal[-1]] = 0.9
      outputs.append(line)
      #print("output = ", line) # 학습해야할 결과값

   device = 'cpu' # 'cpu'로 계산할지 'gpu'로 계산할지 지정, 'gpu'를 사용하려면 pytorch의 gpu 버전을 설치해야 함

   X = torch.FloatTensor(inputs).to(device) # 입력 데이터
   Y = torch.FloatTensor(outputs).to(device) # 학습해야할 결과값

   try:
      model = torch.load("trained.wgt")
   except Exception as e:
      n_hidden = 128*128
      model = nn.Sequential( # 각 계층별 노드의 갯수 설정
         nn.Linear(128*128, n_hidden, bias=True), # hidden 1의 노드 갯수 : n_hidden
         nn.Sigmoid(),
         nn.Linear(n_hidden, n_hidden-6500, bias=True), # hidden 2의 노드 갯수 : n_hidden - 6500
         nn.Sigmoid(),
         nn.Linear(n_hidden-6500, n_hidden-13000, bias=True), # hidden 3의 노드 갯수 : n_hidden - 13000
         nn.Sigmoid(),
         nn.Linear(n_hidden-13000, 5, bias=True), # 출력 노드 갯수 : 5
         nn.Sigmoid(),
      ).to(device)
   # 너무 많은 노드를 할당하면 컴퓨터의 용량을 초과하여 계산을 할 수 없음.
   
   criterion = torch.nn.BCELoss().to(device)
   optimizer = torch.optim.SGD(model.parameters(), lr=1)

   for epoch in range(100): # 학습 횟수는 데이터의 크기, 종류에 따라 변할 수 있음
      # forward 연산
      hypothesis = model(X)

      # 비용 함수
      cost = criterion(hypothesis, Y)
      optimizer.zero_grad()

      # backpropagation
      cost.backward()
      optimizer.step()

      # 각 에포크마다 비용을 출력, 비용은 학습해야할 값과 계산값의 차이를 의미 
      print(epoch, cost.item())

   # 학습 완료후 각 입력데이터에 대한 결과값 출력, 학습이 어느정도 되었는지 확인하기 위해 사용
   # for i in range(len(outputs)):
   #    print(list(hypothesis[i].detach().cpu().numpy()))

   end_time = time.time()

   print("time = ", end_time - start_time)
   torch.save(model, "trained.wgt")
   return

def recog():
   return

if __name__ == "__main__":
   train()
   recog()


